package carrental;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.io.Serial;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Serial
    private static final long serialVersionUID = 1L;  // Added serialVersionUID
    
    // Hardcoded users
    private static final User[] users = {
        new User("jinay", "jinay@2005"),
        new User("aadi", "aadi@2005"),
        new User("riya", "riya@2005")
    };
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        for (User user : users) {
            if (user.getUsername().equals(username) && 
                user.getPassword().equals(password)) {
                
                HttpSession session = request.getSession();
                session.setAttribute("user", username);
                response.sendRedirect("cars.jsp");
                return;
            }
        }
        
        request.setAttribute("error", "Invalid username or password");
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
}