package carrental;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.io.Serial;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet("/cars")
public class CarServlet extends HttpServlet {
    @Serial
    private static final long serialVersionUID = 1L;
    
    // Hardcoded cars
    private static final List<Car> cars = new ArrayList<>();
    
    static {
        Random random = new Random();
        
        // Locations in Pune
        String[] locations = {
            "Kothrud", "Hinjewadi", "Baner", "Shivajinagar", "Hadapsar",
            "Koregaon Park", "Viman Nagar", "Aundh", "Wakad", "Kharadi"
        };
        
        // Features
        String[] transmissions = {"Manual", "Automatic"};
        String[] fuelTypes = {"Petrol", "Diesel", "CNG"};
        int[] seatingCapacities = {4, 5, 7, 8};
        
        // Create cars with the correct constructor signature (id, model, price, available)
        Car car1 = new Car(1, "Toyota Camry", 2500.0, true);
        Car car2 = new Car(2, "Honda Civic", 2000.0, true);
        Car car3 = new Car(3, "Tesla Model 3", 4500.0, true);
        
        // Set additional properties
        for (Car car : new Car[]{car1, car2, car3}) {
            car.setLocation(locations[random.nextInt(locations.length)]);
            car.setRegistrationNumber("MH12-" + (char)('A' + random.nextInt(26)) + (char)('A' + random.nextInt(26)) + "-" + String.format("%04d", random.nextInt(10000)));
            car.setTransmission(transmissions[random.nextInt(transmissions.length)]);
            car.setFuelType(fuelTypes[random.nextInt(fuelTypes.length)]);
            car.setSeatingCapacity(seatingCapacities[random.nextInt(seatingCapacities.length)]);
        }
        
        // Add cars to the list
        cars.add(car1);
        cars.add(car2);
        cars.add(car3);
        
        // Add more cars
        String[] models = {
            "Hyundai Creta", "Mahindra XUV500", "Tata Nexon", "Toyota Fortuner", 
            "Maruti Baleno", "Hyundai Verna", "Mahindra Scorpio", "Tata Harrier"
        };
        
        for (int i = 4; i <= 10; i++) {
            String model = models[random.nextInt(models.length)];
            double price = 1500 + random.nextInt(3000);
            boolean available = random.nextBoolean();
            
            Car car = new Car(i, model, price, available);
            
            car.setLocation(locations[random.nextInt(locations.length)]);
            car.setRegistrationNumber("MH12-" + (char)('A' + random.nextInt(26)) + (char)('A' + random.nextInt(26)) + "-" + String.format("%04d", random.nextInt(10000)));
            car.setTransmission(transmissions[random.nextInt(transmissions.length)]);
            car.setFuelType(fuelTypes[random.nextInt(fuelTypes.length)]);
            car.setSeatingCapacity(seatingCapacities[random.nextInt(seatingCapacities.length)]);
            
            cars.add(car);
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get filter parameters
        String location = request.getParameter("location");
        String carType = request.getParameter("carType");
        String priceRange = request.getParameter("priceRange");
        String transmission = request.getParameter("transmission");
        
        // Create a filtered list
        List<Car> filteredCars = new ArrayList<>();
        
        // Apply filters
        for (Car car : cars) {
            boolean locationMatch = true;
            boolean carTypeMatch = true;
            boolean priceMatch = true;
            boolean transmissionMatch = true;
            
            // Location filter
            if (location != null && !location.isEmpty()) {
                locationMatch = car.getLocation() != null && car.getLocation().equals(location);
            }
            
            // Car type filter (assuming car type is related to model)
            if (carType != null && !carType.isEmpty()) {
                String model = car.getModel().toLowerCase();
                
                switch (carType.toLowerCase()) {
                    case "sedan":
                        carTypeMatch = model.contains("camry") || model.contains("civic") || 
                                       model.contains("verna") || model.contains("dzire");
                        break;
                    case "suv":
                        carTypeMatch = model.contains("creta") || model.contains("xuv") || 
                                       model.contains("scorpio") || model.contains("fortuner") || 
                                       model.contains("harrier") || model.contains("safari");
                        break;
                    case "hatchback":
                        carTypeMatch = model.contains("baleno") || model.contains("swift") || 
                                       model.contains("i20") || model.contains("nexon");
                        break;
                    default:
                        carTypeMatch = true;
                }
            }
            
            // Price range filter
            if (priceRange != null && !priceRange.isEmpty()) {
                double price = car.getPrice();
                
                switch (priceRange) {
                    case "0-1500":
                        priceMatch = price >= 0 && price <= 1500;
                        break;
                    case "1500-3000":
                        priceMatch = price > 1500 && price <= 3000;
                        break;
                    case "3000-5000":
                        priceMatch = price > 3000 && price <= 5000;
                        break;
                    case "5000+":
                        priceMatch = price > 5000;
                        break;
                    default:
                        priceMatch = true;
                }
            }
            
            // Transmission filter
            if (transmission != null && !transmission.isEmpty()) {
                transmissionMatch = car.getTransmission() != null && 
                                   car.getTransmission().equalsIgnoreCase(transmission);
            }
            
            // Add car if it matches all filters
            if (locationMatch && carTypeMatch && priceMatch && transmissionMatch) {
                filteredCars.add(car);
            }
        }
        
        request.setAttribute("cars", filteredCars);
        request.getRequestDispatcher("cars.jsp").forward(request, response);
    }
}