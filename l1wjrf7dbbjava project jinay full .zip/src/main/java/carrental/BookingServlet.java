package carrental;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@WebServlet("/book")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Added serialVersionUID

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("user");
        
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int carId = Integer.parseInt(request.getParameter("carId"));
            LocalDateTime startDateTime = LocalDateTime.parse(request.getParameter("startDateTime"));
            LocalDateTime endDateTime = LocalDateTime.parse(request.getParameter("endDateTime"));
            double dailyRate = Double.parseDouble(request.getParameter("dailyRate"));
            
            if(endDateTime.isBefore(startDateTime)) {
                throw new ServletException("End time must be after start time");
            }
            
            long totalHours = ChronoUnit.HOURS.between(startDateTime, endDateTime);
            if(totalHours < 1) {
                throw new ServletException("Minimum booking duration is 1 hour");
            }
            
            // Calculate pricing based on 24-hour days
            long fullDays = totalHours / 24;
            long remainingHours = totalHours % 24;
            double totalPrice = fullDays * dailyRate;
            
            // Calculate remaining hours cost
            if(remainingHours > 0) {
                double hourlyRate = dailyRate / 24;
                totalPrice += Math.ceil(remainingHours * hourlyRate);
            }
            
            // Store booking details
            session.setAttribute("bookingCarId", carId);
            session.setAttribute("bookingStart", startDateTime);
            session.setAttribute("bookingEnd", endDateTime);
            session.setAttribute("bookingTotal", totalPrice);
            session.setAttribute("bookingDuration", totalHours + " hours (" + 
                fullDays + " days " + remainingHours + " hours)");
            
            request.getRequestDispatcher("book.jsp").forward(request, response);
            
        } catch (Exception e) {
            request.setAttribute("error", "Booking error: " + e.getMessage());
            request.getRequestDispatcher("book.jsp").forward(request, response);
        }
    }
}